package sparkConsumer;

import org.apache.log4j.Logger;

/**
 * To check the exceptions occured based on the enamolies from the spark readings
 */
public class SimpleChecker  {

    private Logger log = Logger.getLogger(SimpleChecker.class);

    /**
     * This method will check any exceptions occuring in the CPU Load and Total Memory used
     *
     * @param metrics The metrics of a host sytem.
     * @return alert metrics
     */
    public String getAlert(PerfMetrics metrics) {

        String alert;
        alert = checkAnamolies(metrics);
        return alert;
    }

    /**
     * Function to check the exceptions based on teh defined range of values for
     * both CPU Load and total memory used.
     *
     * @param metrics The performance metrics of the host
     * @return alert message
     */
    private String checkAnamolies(PerfMetrics metrics) {
    	System.out.println("check expected values");
        if (metrics.cpuUsage >1 || metrics.cpuUsage <0) {
            return "cpuUsage ="+metrics.cpuUsage +" . CPU usage is exceeding the expected range ";
        } else if (metrics.totalMemoryLoad >100 ) {
            return  "totalMemoryLoad ="+metrics.totalMemoryLoad +" . totalMemoryLoad is exceeding the expected range ";
        }
        return "";
     }
  }

  
