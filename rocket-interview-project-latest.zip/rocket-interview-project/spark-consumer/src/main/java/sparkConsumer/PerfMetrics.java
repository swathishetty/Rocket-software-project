package sparkConsumer;

/**
 * A bean class to get the performance metrics of the host sytem.
 * 
 */
public class PerfMetrics {

    public double cpuUsage = 0.0;
	public long totalMemoryLoad = 0;

  
    public PerfMetrics(double cpuUsage,long  totalMemoryLoad) {
        this.totalMemoryLoad = totalMemoryLoad;
        this.cpuUsage = cpuUsage;
        System.out.println(" totalMemoryLoad "+totalMemoryLoad+" cpuUsage"+cpuUsage);
    }
}
