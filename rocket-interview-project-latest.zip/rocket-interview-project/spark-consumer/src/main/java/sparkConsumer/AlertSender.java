package sparkConsumer;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;
import com.google.gson.Gson;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import java.io.IOException;

public class AlertSender {

    private Logger log = Logger.getLogger(AlertSender.class);
    private String sparkStreamServerURL = "http://localhost:3000";
    private HttpClient client = HttpClientBuilder.create().build();

    /**
     * Creates a new alert server object to send alerts to the server
     */
    public AlertSender() {
    }

    /**
     * Send the alert to the given server as a POST.
     *
     * @param alert alert string
     */
    public void sendAlert(String alert) {

        try {
            HttpPost request = new HttpPost(sparkStreamServerURL + "/perfalerts");
            StringEntity params = new StringEntity(new Gson().toJson(alert));
            request.addHeader("content-type", "application/json");
            request.setEntity(params);
            HttpResponse response = client.execute(request);
        } catch (IOException ex) {
            log.error("Unable to make request", ex);
        }
    }
}
