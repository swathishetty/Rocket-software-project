package sparkConsumer;

import scala.Tuple2;

import org.apache.spark.streaming.Time;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;
import org.apache.spark.streaming.kafka010.ConsumerStrategies;
import org.apache.spark.streaming.kafka010.KafkaUtils;
import org.apache.spark.streaming.kafka010.LocationStrategies;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.log4j.PropertyConfigurator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.api.java.function.VoidFunction2;
import org.apache.spark.streaming.Durations;
import com.google.gson.Gson;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/*
 * Class to read the performance metrics from the kafka server
 * via the SPARK API's.
 * 
 */
public class SparkMetricsReader {

    public static void main(String[] args) throws Exception {
        PropertyConfigurator.configure(SparkMetricsReader.class.getClassLoader().getResource("conf/log4j.properties"));
        run();
    }

    /**
     * Run method to invoke Spark application to consume performance values from the Kafka server
     * and check for enamolies.
     *
     * @throws InterruptedException .
     * @throws  
     */
    private static void run() throws InterruptedException {

        //Spark configurations
        SparkConf sparkConf = new SparkConf().setAppName("SparkReader").setMaster("local[*]");
        Properties configProp = new Properties();
        //reading the property from teh configuration files
        try (InputStream input = new FileInputStream("config.properties")) {
        	 configProp.load(input);
         } catch (IOException ex) {
             System.err.println("Unable to load configuration file: " + "config.properties");
             ex.printStackTrace();
         }
        //reading the streams in batches for each 5 seconds
        int duration = Integer.parseInt(configProp.getProperty("spark.period")); //value is 5
        System.out.println("before javastrea");
        JavaStreamingContext javaStreamingContext = new JavaStreamingContext(sparkConf, Durations.seconds(duration));
        // Consuming the kafka stream
        consumeKafkaStream(javaStreamingContext,configProp);
        // Submit the application
        javaStreamingContext.start();
        javaStreamingContext.awaitTermination();
    }
    
    public static void consumeKafkaStream(JavaStreamingContext streamingContext, Properties prop) {
        System.out.println("inside connsume stream");
        String topic = "sensor";
        Set<String> topicsSet = new HashSet<>(Collections.singleton(topic));
        System.out.println("topicsSet "+topicsSet);
        Map<String, Object> kafkaParams = getParameters(prop);
        System.out.println("kafkaParams "+kafkaParams);
        //consuming from Kafka
        final JavaInputDStream<ConsumerRecord<String, String>> stream = KafkaUtils
                .createDirectStream(streamingContext,
                        LocationStrategies.PreferConsistent(),
                        ConsumerStrategies.Subscribe(topicsSet, kafkaParams));
         System.out.println("stream data "+stream);
       stream.mapToPair((PairFunction<ConsumerRecord<String, String>, String, String>)
                record -> new Tuple2<>(record.key(), record.value()));       
        // checking the exceptions from the metric data
        stream.foreachRDD((VoidFunction2<JavaRDD<ConsumerRecord<String, String>>, Time>) (rdd, time) -> {
         System.out.println("rdd count "+ rdd.count());
            rdd.foreach(record -> {
            	 System.out.println("record "+record);
                 PerfMetrics metrics = new Gson().fromJson(record.value(), PerfMetrics.class);
                 System.out.println("metricsss "+metrics);
                 String alert = new SimpleChecker().getAlert(metrics);
                 System.out.println("alert "+alert);
                 if (alert != null) {
                	System.out.println("alert spark "+alert);
                    new AlertSender().sendAlert(alert);
                }
            });
        });
        System.out.println("stream data "+ stream);
    }

    /**
     * kafka parameters to read the performancevalues from the servers
     *
     * @return Map The Kafka parameters.
     */
    private static Map<String, Object> getParameters( Properties prop) {

        Map<String, Object> kafkaParams = new HashMap<>();
        kafkaParams.put("bootstrap.servers", prop.getProperty("bootstrap.servers"));
        kafkaParams.put("group.id", "2");
        kafkaParams.put("key.deserializer", StringDeserializer.class);
        kafkaParams.put("value.deserializer", StringDeserializer.class);
        return kafkaParams;
    }
}
