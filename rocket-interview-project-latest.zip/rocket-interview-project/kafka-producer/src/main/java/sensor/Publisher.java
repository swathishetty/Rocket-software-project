package sensor;


import org.apache.edgent.topology.TStream;

/**
 * Interface for the publisher
 * 
 */
public interface Publisher<T> {

    /**
     * publish data to the topics.
     *
     * @param stream The Edgent stream to publish.
     */
    void publish(TStream<T> stream);
}
