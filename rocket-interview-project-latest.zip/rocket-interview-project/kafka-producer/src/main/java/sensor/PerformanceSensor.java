package sensor;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;
import org.apache.edgent.function.Supplier;


/**
 * A Sensor to get the performance metric of the host such as 
 * CPU load and Total Memory Load
 * 
 */
public class PerformanceSensor implements Supplier<PerfMetrics> {

    private OperatingSystemMXBean osPerfMetrics;
    public PerformanceSensor() {
    	 osPerfMetrics = (OperatingSystemMXBean)ManagementFactory.getOperatingSystemMXBean();
    }

    /**
     * Implementation of the Supplier.get method to read the values.
     *
     * @return cpu load and total memory
     */
    @Override
    public PerfMetrics get() {
    	double cpuUsage = osPerfMetrics.getSystemCpuLoad();
        long totalMemoryLoad = osPerfMetrics.getTotalPhysicalMemorySize();
        return new PerfMetrics(cpuUsage, totalMemoryLoad);
    }
}
