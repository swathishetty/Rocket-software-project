package sensor;


import com.google.gson.Gson;
import org.apache.edgent.connectors.kafka.KafkaProducer;
import org.apache.edgent.topology.TStream;
import org.apache.edgent.topology.Topology;

import java.util.Map;

/**
 * kafka producer to produce the performance metrics data to the kafka server
 */
public class KafkaPublisher<T> implements Publisher<T> {

    private String topic;
    private KafkaProducer kafka;

    /**
     * kafka producer to put the data into the streams.
     *
     * @param topology The Edgent topology for the streams.
     * @param config kafka connection configurations.
     * @param topic used to publish the data.
     */
    public KafkaPublisher(Topology topology, Map<String, Object> config, String topic) {
        if (topic != null) {
            this.topic = topic;
        }

        kafka = new KafkaProducer(topology, () -> config);
    }

    /**
     * To publish the data to the kafkastream
     * 
     * @param stream The Edgent stream to publish.
     */
    @Override
    public void publish(TStream<T> stream) {
        kafka.publish(stream.map(e -> new Gson().toJson(e)), topic);
    }
}
