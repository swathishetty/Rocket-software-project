package sensor;


/**
 * A bean class to get the performance metrics of the host sytem.
 * 
 */
public class PerfMetrics {

    private double cpuUsage = 0.0;
	private long totalMemoryLoad = 0;

  
    public PerfMetrics(double cpuUsage,long  totalMemoryLoad) {
        this.totalMemoryLoad = totalMemoryLoad;
        this.cpuUsage = cpuUsage;
        System.out.println(" totalMemoryLoad "+totalMemoryLoad+" cpuUsage"+cpuUsage);
    }

  
}
