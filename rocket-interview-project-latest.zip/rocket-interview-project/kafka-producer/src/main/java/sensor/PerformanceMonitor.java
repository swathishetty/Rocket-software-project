package sensor;
import org.apache.log4j.BasicConfigurator;

import com.google.gson.Gson;

import org.apache.edgent.connectors.kafka.KafkaProducer;
import org.apache.edgent.providers.direct.DirectProvider;
import org.apache.edgent.topology.TStream;
import org.apache.edgent.topology.Topology;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.HashMap;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * A sensor program that reads the performance metrics of the host system
 * using the Apache Edgent API's and publishs the same to the kafka server.
 * 
 */
public class PerformanceMonitor {
  
    public static void main(String[] args) {
        run();
    }

    /**
     * Start the performance metrics and polls for each second and publishs 
     * the metrics to the kafka server
     * 
     */
    private static void run() {
        DirectProvider directProvider = new DirectProvider();
        Topology topology = directProvider.newTopology("kafkaSensorDataPublisher");
        Properties configProp = new Properties();
        KafkaProducer kafka;
        // Poll the system's performance every second
        TStream<PerfMetrics> performanceMetrics = topology.poll(new PerformanceSensor(), 1L, TimeUnit.SECONDS);
        System.out.println("performanceMetrics "+performanceMetrics);
        // Create and configure the KafkaPublisher 
        Map<String, Object> configurations = new HashMap<>();
        //reading the configuration property file
        try (InputStream input = new FileInputStream("config.properties")) {
        	configProp.load(input);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        //basic configuration for the zookeeper and the kafka server
        configurations.put("bootstrap.servers", configProp.getProperty("bootstrap.servers"));
        configurations.put("zookeeper.connect", configProp.getProperty("zookeeper.connect"));
        kafka = new KafkaProducer(topology, () -> configurations);
        //publisher to publish the stream sto the kafk atopic(sensor)
        kafka.publish(performanceMetrics.map(e -> new Gson().toJson(e)), "sensor");
        // Submit the topology and start sending the  messages
        directProvider.submit(topology);
    }

}
